/** Automatically generated file. DO NOT MODIFY */
package com.app.kasifoodapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}